RAHUL STUDIO 18.1 — PROYEK ANDROID + BUILD APK OTOMATIS

PENTING:
ZIP ini belum berisi APK. ZIP berisi proyek Android dan workflow GitHub Actions untuk membangun APK otomatis di cloud.

CARA PALING MUDAH (perlu satu kali pengaturan GitHub):
1. Buat akun / masuk ke https://github.com
2. Buat repository baru bernama rahul-studio-android (boleh Private).
3. Unggah seluruh isi folder proyek dari ZIP ini ke repository, termasuk folder tersembunyi .github/workflows.
   Pastikan build.gradle, settings.gradle, gradle.properties, dan folder app berada di akar repository.
4. Buka tab Actions di repository.
5. Pilih workflow "Build RAHUL STUDIO APK", lalu tekan "Run workflow".
6. Tunggu sampai workflow selesai dengan status hijau.
7. Buka hasil workflow, bagian Artifacts, unduh "RAHUL-STUDIO-18.1-APK".
8. Ekstrak ZIP artifact tersebut. Di dalamnya ada app-debug.apk.
9. Buka APK di HP Android dan izinkan "Install unknown apps" jika Android memintanya.

BUILD OTOMATIS:
Workflow juga berjalan setiap kali ada push ke branch main. Untuk build manual, jalankan dari tab Actions.

YANG SUDAH DISIAPKAN:
- Android WebView fullscreen.
- HTML RAHUL STUDIO 18.1 dimuat dari assets lokal.
- JavaScript dan penyimpanan lokal WebView aktif.
- Pemilih file untuk unggah gambar/video.
- Link platform AI dibuka melalui browser Android.
- Android back navigation.
- GitHub Actions workflow untuk membangun debug APK.

BATASAN:
- Saya tidak dapat membuat APK di sesi ini karena Android SDK/Gradle tidak tersedia di lingkungan lokal.
- GitHub Actions membangun APK di cloud setelah proyek diunggah dan workflow dijalankan.
- APK debug dapat dipasang untuk penggunaan pribadi, tetapi belum merupakan rilis Play Store.
- Render AI tetap berjalan pada platform AI eksternal; tidak ada API render langsung yang ditambahkan.
