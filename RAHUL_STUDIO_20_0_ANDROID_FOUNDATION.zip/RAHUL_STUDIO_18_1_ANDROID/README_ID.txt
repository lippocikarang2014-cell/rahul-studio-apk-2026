RAHUL STUDIO 20.0 — PROYEK ANDROID

Ini adalah proyek sumber Android Studio (WebView wrapper), bukan APK siap instal.
File aplikasi HTML 20.0 sudah ditempatkan di app/src/main/assets/index.html.

CARA MEMBUAT APK:
1. Instal Android Studio pada komputer.
2. Ekstrak ZIP proyek ini.
3. Android Studio > Open > pilih folder RAHUL_STUDIO_18_1_ANDROID.
4. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh komponen SDK yang diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.

FITUR WRAPPER:
- Membuka aplikasi HTML dalam layar penuh.
- JavaScript dan localStorage WebView aktif.
- Unggah file gambar/video melalui pemilih file Android.
- Tautan platform AI eksternal dibuka melalui browser Android.
- Tombol Back Android menangani navigasi WebView.

CATATAN:
- Perlu komputer dengan Android Studio + Android SDK untuk membangun APK.
- Tidak ada API render AI yang ditambahkan. Render tetap dilakukan pada platform AI yang dipilih.
- Data lokal aplikasi tersimpan pada penyimpanan WebView. Hapus data aplikasi dapat menghapus data lokal; lakukan backup proyek.
